package com.mycompany.labactivity1;


import javax.swing.JOptionPane;


//comments done individuly on parts done by group members 

public class LabActivity1 
{


    public static void main(String[] args) {
        // Array to store artist names
        String[] artists = {"Ed Sheeran", "Pink", "Bruno Mars", "Foo Fighters", "Taylor Swift"};

        // 2D array to store sales data: {CD sales, DVD sales, Blu-ray sales}
        int[][] salesData = {
            {900000, 800000, 500000},  // Sales for Ed Sheeran
//coded by Shuan

            {700000, 500000, 500000},  // Sales for Pink
//coded by Shuan

            {800000, 100000, 50000},   // Sales for Bruno Mars
//coded by Shuan

            {100000, 200000, 200000},  // Sales for Foo Fighters
//coded by Shuan

            {300000, 100000, 50000}    // Sales for Taylor Swift
//coded by Shuan
        };

        // Get user input for position
        String positionInput = JOptionPane.showInputDialog(null,
                "Enter a position between 1 and 5 to view the artist's sales:");

        if (positionInput != null) {
            int position = Integer.parseInt(positionInput);
//coded by Mnqobi

            // Validate position
            if (position >= 1 && position <= 5) {  
//coded by Oratile

                // Adjust for 0-based index
                int artistIndex = position - 1;
//coded by Oratile

                // Get the sales data for the selected artist
                String artistName = artists[artistIndex];
//coded by Oratile

                int cdSales = salesData[artistIndex][0];
//coded by Oratile

                int dvdSales = salesData[artistIndex][1];
//coded by Oratile

                int bluRaySales = salesData[artistIndex][2];
//coded by Oratile

                int totalSales = cdSales + dvdSales + bluRaySales;
//coded by Oratile

                // Construct the message
                String message = "Artist: " + artistName + "\n" +
//coded by Mnqobi
                        "CD Sales: " + cdSales + "\n" +
                        "DVD Sales: " + dvdSales + "\n" +
                        "Blu-ray Sales: " + bluRaySales + "\n" +
                        "Total Sales: " + totalSales;

                // Display the message
                JOptionPane.showMessageDialog(null, message);
//coded by Mnqobi

                // Ask if the user wants to go back
                int choice = JOptionPane.showConfirmDialog(null, "Do you want to go back?", "Back", JOptionPane.YES_NO_OPTION);
// coded by Shaun Masuku
                
                if (choice == JOptionPane.YES_OPTION) {
                    main(args);  // Recursively call main to go back
                } else {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                }

            } else {
                // Invalid position
                JOptionPane.showMessageDialog(null,
                        "Invalid position! Please enter a number between 1 and 5.");
//coded by Mnqobi
            }
        } else {
            JOptionPane.showMessageDialog(null, "No input provided! Exiting the program.");
        }
    }
}  